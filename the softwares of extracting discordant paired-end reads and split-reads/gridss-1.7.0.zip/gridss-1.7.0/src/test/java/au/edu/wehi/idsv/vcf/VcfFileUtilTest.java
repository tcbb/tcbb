package au.edu.wehi.idsv.vcf;

public class VcfFileUtilTest {
	/*
	public class TestCommandLineProgram extends CommandLineProgram {
		public TestCommandLineProgram() {
			TMP_DIR = ImmutableList.of(new File("C:/Temp"));
			REFERENCE = Hg19Tests.findHg19Reference();
			//MAX_RECORDS_IN_RAM = 10000;
		}
		@Override
		protected int doWork() {
			// TODO Auto-generated method stub
			return 0;
		}
	}
	@Test
	@Category(Hg19Tests.class)
	public void sort_should_not_leak_memory() throws IOException {
		// Technically it's not a memory leak: it's an insanely massive index file due to
		// out of order records on the same contig
		ProcessingContext pc = new TestCommandLineProgram().getContext();
		new SortCallable(pc,
				new File("CPCG0100.vcf.idsv.chr1.assemblyremote.unsorted.vcf"),
				new File("C:/Temp/testout.vcf"),
				VariantContextDirectedBreakpoint.ByRemoteBreakendLocationStartRaw(pc)).call();
	}
	*/
}

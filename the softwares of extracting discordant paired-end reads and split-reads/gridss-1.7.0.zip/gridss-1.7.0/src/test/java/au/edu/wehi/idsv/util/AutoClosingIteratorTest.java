package au.edu.wehi.idsv.util;


public class AutoClosingIteratorTest {

}

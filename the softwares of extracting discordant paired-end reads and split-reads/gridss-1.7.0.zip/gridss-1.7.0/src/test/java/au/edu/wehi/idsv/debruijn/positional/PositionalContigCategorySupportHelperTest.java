package au.edu.wehi.idsv.debruijn.positional;

import au.edu.wehi.idsv.TestHelper;

public class PositionalContigCategorySupportHelperTest extends TestHelper {
}

package au.edu.wehi.idsv.vcf;

public enum SvType {
	DEL,
	INS,
	DUP,
	INV,
	CNV,
	BND
}

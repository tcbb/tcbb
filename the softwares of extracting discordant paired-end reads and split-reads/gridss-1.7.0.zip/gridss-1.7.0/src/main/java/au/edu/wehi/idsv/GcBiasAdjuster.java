package au.edu.wehi.idsv;

public interface GcBiasAdjuster {
	public double adjustmentMultiplier(int gcPercentage);
}

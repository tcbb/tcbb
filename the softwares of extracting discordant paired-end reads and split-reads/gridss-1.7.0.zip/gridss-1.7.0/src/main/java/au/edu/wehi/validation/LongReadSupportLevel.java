package au.edu.wehi.validation;

import java.util.ArrayList;
import java.util.List;

public class LongReadSupportLevel {
	public List<Integer> startClipLocations = new ArrayList<Integer>();
	public List<Integer> spanningAlignments = new ArrayList<Integer>();
	public List<Integer> endClipLocations = new ArrayList<Integer>();
}